#include <linux/mmc/host.h>
#include <linux/fs.h>
#include <linux/wlan_plat.h>
#include <asm/uaccess.h>
#include <linux/platform_device.h>
#include <linux/regulator/consumer.h>
#include <linux/gpio.h>
#include <linux/err.h>
#include <linux/delay.h>

#ifdef CONFIG_SOC_T40
#include <soc/gpio.h>
#include <soc/mmc.h>
#elif defined CONFIG_SOC_T31
#include <gpio.h>
#include <mach/jzmmc.h>
#endif

#define GPIO_WIFI_WAKEUP     	GPIO_PC(17)
#define GPIO_WIFI_RST_N			GPIO_PC(16)
#define SDIO_WIFI_POWER         GPIO_PC(18)
#define WLAN_SDIO_INDEX			1

/* static int wl_pw_en = 0; */
extern void rtc32k_enable(void);
extern void rtc32k_disable(void);

void wlan_pw_en_enable(void)
{
}

void wlan_pw_en_disable(void)
{
}


/*
    It calls jzmmc_manual_detect() to re-scan SDIO card
*/
int platform_wifi_power_on(void)
{

    gpio_request(SDIO_WIFI_POWER, "sdio_wifi_power_on");
	
	gpio_direction_output(SDIO_WIFI_POWER, 1);
	printk("wlan power on\n");
	msleep(10);

	jzmmc_manual_detect(WLAN_SDIO_INDEX, 1);

	return 0;
}

int platform_wifi_power_off(void)
{
	//gpio_direction_output(SDIO_WIFI_POWER, 0);
    gpio_free(SDIO_WIFI_POWER);
	printk("wlan power off\n");
	msleep(10);
	jzmmc_manual_detect(WLAN_SDIO_INDEX, 0);
	return 0;
}
